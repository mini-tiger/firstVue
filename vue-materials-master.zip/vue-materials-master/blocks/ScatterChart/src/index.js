import ScatterChart from './ScatterChart';

export default ScatterChart;
