# map-toggle-chart

简介：map-toggle-chart

基于v-chart 地图类型切换，amap支持主题类型切换，bmap支持底图切换。

![MapToggleChart-AMap-01](https://user-images.githubusercontent.com/18508817/40878035-7d88664e-66bd-11e8-8dd3-0b997f3f3800.png)

![MapToggleChart-AMap-02](https://user-images.githubusercontent.com/18508817/40878048-b260eecc-66bd-11e8-80ff-2dc0bfc5d800.png)

![MapToggleChart-BMap-01](https://user-images.githubusercontent.com/18508817/40877954-fed6a212-66bb-11e8-8e14-9081bc598cd2.png)
