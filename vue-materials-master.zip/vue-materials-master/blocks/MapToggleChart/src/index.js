import MapToggleChart from './MapToggleChart';

export default MapToggleChart;
