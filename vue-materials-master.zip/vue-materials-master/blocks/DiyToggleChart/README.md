# diy-toggle-chart

简介：diy-toggle-chart

v-chart 自定义图表类型切换，支持Line、Histogram、Bar、Pie、Ring、Waterfall和Funnel，七种图表类型切换

![DiyToggleChart-Line](https://user-images.githubusercontent.com/18508817/40872239-78c74606-667d-11e8-855d-efd7ed7d6d9e.png)

![DiyToggleChart-Ring](https://user-images.githubusercontent.com/18508817/40873801-bf4a596c-6699-11e8-8839-a625e52212fd.png)

![DiyToggleChart-Funnel](https://user-images.githubusercontent.com/18508817/40877732-653f6038-66b8-11e8-8248-b5c084d430c0.png)
