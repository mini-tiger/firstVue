import DiyToggleChart from './DiyToggleChart';

export default DiyToggleChart;
