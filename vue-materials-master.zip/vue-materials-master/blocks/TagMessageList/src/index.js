import TagMessageList from './TagMessageList';

export default TagMessageList;
