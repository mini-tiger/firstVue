import WaterfallChart from './WaterfallChart';

export default WaterfallChart;
