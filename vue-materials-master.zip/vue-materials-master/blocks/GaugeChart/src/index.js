import GaugeChart from './GaugeChart';

export default GaugeChart;
