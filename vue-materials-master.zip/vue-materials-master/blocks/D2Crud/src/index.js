import D2Crud from './D2Crud';

export default D2Crud;
