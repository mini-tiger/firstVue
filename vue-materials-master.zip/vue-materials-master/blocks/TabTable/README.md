# tab-table

简介：基于element的标签页表格组合

基于element的标签页表格组合

![截图](https://img.alicdn.com/tfs/TB1IYWRXeuSBuNjy1XcXXcYjFXa-1902-906.png)
