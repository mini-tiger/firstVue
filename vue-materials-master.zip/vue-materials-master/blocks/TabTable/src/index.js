import TabTable from './TabTable';

export default TabTable;
