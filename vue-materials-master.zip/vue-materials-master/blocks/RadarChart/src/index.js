import RadarChart from './RadarChart';

export default RadarChart;
