# bar-chart-block

简介：条形图

![截图](https://img.alicdn.com/tfs/TB1gSTgpKuSBuNjy1XcXXcYjFXa-2016-876.png)
