import RingChart from './RingChart';

export default RingChart;
