# not-permission

简介：无权限提示

基于element-ui组件的无权限提示

![NotPermission](https://user-images.githubusercontent.com/18508817/40156536-aa55aa7c-59cc-11e8-971a-ecc339655041.png)
