import FixedTable from './FixedTable';

export default FixedTable;
