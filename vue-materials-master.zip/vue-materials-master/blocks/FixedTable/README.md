# fixed-table-block

简介：固定表格

![截图](https://img.alicdn.com/tfs/TB15b7.pTtYBeNjy1XdXXXXyVXa-1964-660.png)
