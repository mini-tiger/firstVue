# histogram-chart-block

简介：柱状图

![截图](https://img.alicdn.com/tfs/TB1Gfs.pTtYBeNjy1XdXXXXyVXa-1944-848.png)
