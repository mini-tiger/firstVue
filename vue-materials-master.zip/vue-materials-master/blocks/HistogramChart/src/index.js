import HistogramChart from './HistogramChart';

export default HistogramChart;
