# basic-not-found

简介：404 报错提示

基于element-ui组件的404 报错提示

![BasicNotFound](https://user-images.githubusercontent.com/18508817/40071509-8a83af2a-58a3-11e8-926a-42a70c06bc71.png)
