# basic-exception

简介：基础异常报错

基于element-ui组件的基础异常报错

![BasicException](https://user-images.githubusercontent.com/18508817/40156388-bf1a1b92-59cb-11e8-913c-b31886149263.png)
