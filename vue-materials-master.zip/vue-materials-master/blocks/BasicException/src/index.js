import BasicException from './BasicException';

export default BasicException;
