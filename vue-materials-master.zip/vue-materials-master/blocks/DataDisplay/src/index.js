import DataDisplay from './DataDisplay.vue';

export default DataDisplay;
