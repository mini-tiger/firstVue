# empty-content

简介：无权限提示

基于 element-ui 组件的无权限提示

![EmptyContent](https://img.alicdn.com/tfs/TB161Wer1uSBuNjy1XcXXcYjFXa-2528-1266.png)
