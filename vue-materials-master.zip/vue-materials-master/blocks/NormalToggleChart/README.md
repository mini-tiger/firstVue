# normal-toggle-chart

简介：normal-toggle-chart

v-chart 自带的图表切换

![NormalToggleChart-Line](https://user-images.githubusercontent.com/18508817/40877809-61862066-66b9-11e8-964f-ef44f96f499b.png)

![NormalToggleChart-Bar](https://user-images.githubusercontent.com/18508817/40877799-2d529a0e-66b9-11e8-8d78-81c072c61dc7.png)