import NormalToggleChart from './NormalToggleChart';

export default NormalToggleChart;
