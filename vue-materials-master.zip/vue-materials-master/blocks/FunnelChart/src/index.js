import FunnelChart from './FunnelChart';

export default FunnelChart;
