import LineChart from './LineChart';

export default LineChart;
