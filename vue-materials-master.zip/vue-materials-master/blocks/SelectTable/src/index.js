import SelectTable from './SelectTable';

export default SelectTable;
