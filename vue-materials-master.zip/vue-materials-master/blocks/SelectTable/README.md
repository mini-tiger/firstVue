# select-table

简介：多选表格

多选表格与批量操作

![SelectTable](https://user-images.githubusercontent.com/6414178/44146037-6cf5df18-a0c0-11e8-824b-b8d12eddeeaa.png)
