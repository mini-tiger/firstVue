import HeatmapChart from './HeatmapChart';

export default HeatmapChart;
