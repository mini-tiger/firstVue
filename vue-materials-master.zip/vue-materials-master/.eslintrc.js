module.exports = {
  root: true,
  extends: ['plugin:vue/recommended', '@vue/airbnb'],
  rules: {
    'import/extensions': 0,
    'import/no-unresolved': 1,
  },
};
