import BasicContainer from './src';

export default BasicContainer;
