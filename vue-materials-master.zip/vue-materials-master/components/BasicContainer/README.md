# basic-container

简介：区块容器组件

![截图](https://img.alicdn.com/tfs/TB1fCIGnxSYBuNjSspjXXX73VXa-1960-716.png)
