import BasicContainer from './BasicContainer';

export default BasicContainer;
