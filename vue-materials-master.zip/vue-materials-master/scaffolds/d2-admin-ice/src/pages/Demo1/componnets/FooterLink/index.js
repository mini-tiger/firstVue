import FooterLink from './FooterLink'

export default FooterLink
