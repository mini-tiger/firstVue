import Demo2 from './Demo2'

export default Demo2
