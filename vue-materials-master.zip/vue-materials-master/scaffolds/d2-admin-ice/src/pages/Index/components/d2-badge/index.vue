<template>
  <div class="d2-badge">
    <p align="center">
      <a><img src="https://img.shields.io/github/release/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/github/forks/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/github/stars/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/github/issues/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/github/issues-closed/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/github/issues-pr/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/github/issues-pr-closed/d2-projects/d2-admin.svg"/></a>
    </p>
    <p align="center">
      <a><img src="https://img.shields.io/npm/v/@d2-admin/ice-scaffold.svg"/></a>
      <a href="https://www.travis-ci.org/d2-projects/d2-admin"><img src="https://www.travis-ci.org/d2-projects/d2-admin.svg?branch=master"/></a>
      <a><img src="https://img.shields.io/github/last-commit/d2-projects/d2-admin.svg"/></a>
      <a><img src="https://img.shields.io/badge/code_style-standard-brightgreen.svg"/></a>
    </p>
  </div>
</template>

<style lang="scss" scoped>
.d2-badge {
  margin-bottom: 20px;
  p {
    margin: 0px;
    margin-bottom: 2px;
    &:last-child {
      margin-bottom: 0px;
    }
    a {
      display: inline-block;
      margin: 0px 2px;
    }
  }
}
</style>
