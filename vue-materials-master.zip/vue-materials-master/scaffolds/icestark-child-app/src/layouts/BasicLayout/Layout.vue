<template>
  <div class="icestark-child-app">
    <router-view/>
  </div>
</template>
