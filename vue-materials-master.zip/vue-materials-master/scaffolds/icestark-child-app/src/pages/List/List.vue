<template>
  <div>
    <div>小二：列表页面</div>
    <router-link to="/">home</router-link>
    <br />
    <router-link to="/detail">detail</router-link>
  </div>
</template>
