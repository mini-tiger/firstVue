import Detail from './Detail.vue';

export default Detail;
