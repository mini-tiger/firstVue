<template>
  <div>
    <div>小二：详情页面</div>
    <router-link to="/">home</router-link>
    <br />
    <router-link to="/list">list</router-link>
  </div>
</template>
