# icestark Vue 子应用

icestark 基于 Vue 的子应用模板