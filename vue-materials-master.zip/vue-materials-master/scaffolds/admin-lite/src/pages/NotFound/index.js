import NotFound from './NotFound.vue';

export default NotFound;
