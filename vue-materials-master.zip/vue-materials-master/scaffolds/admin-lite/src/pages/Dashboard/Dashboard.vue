<template>
  <div class="dashboard"/>
</template>
